// URL'den parametreleri ayıkla (url, risk, entropy)
const params = new URLSearchParams(window.location.search);
const blockedUrl = params.get("url") || "http://unknown-url.com";
const riskScore = params.get("risk") || "0";
const entropy = params.get("entropy") || "0";

// HTML elemanlarını güncelle
document.getElementById("blockedUrl").textContent = blockedUrl;
document.getElementById("riskScore").textContent = `%${parseFloat(riskScore).toFixed(2)} Risk Skoru`;

// Güvenli bölgeye dön butonu (Geri gider, geçmiş yoksa Google'a yönlendirir)
document.getElementById("btnSafety").addEventListener("click", () => {
  if (window.history.length > 1) {
    window.history.back();
  } else {
    window.location.href = "https://www.google.com";
  }
});

// Yine de devam et butonu (Whitelist'e ekler ve orijinal adrese yönlendirir)
document.getElementById("btnProceed").addEventListener("click", async () => {
  try {
    const urlObj = new URL(blockedUrl);
    const hostname = urlObj.hostname;

    // Mevcut beyaz listeyi al ve yeni domaini ekle
    chrome.storage.local.get(["whitelist"], (result) => {
      const whitelist = result.whitelist || [];
      if (!whitelist.includes(hostname)) {
        whitelist.push(hostname);
      }
      
      // Beyaz listeyi kaydet
      chrome.storage.local.set({ whitelist: whitelist }, () => {
        console.log(`[Shield] ${hostname} beyaz listeye eklendi. Yönlendiriliyor...`);
        // Orijinal adrese yönlendir
        window.location.href = blockedUrl;
      });
    });
  } catch (e) {
    console.error("[Shield] Geçiş izni verilirken hata oluştu:", e);
    window.location.href = blockedUrl;
  }
});
