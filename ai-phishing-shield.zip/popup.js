const BACKEND_API_URL = "https://phishing-detector-backend-production.up.railway.app/api/v1/scan-url";

// Popup açıldığında aktif sekmenin durumunu sorgula
document.addEventListener("DOMContentLoaded", () => {
  chrome.runtime.sendMessage({ action: "getCurrentTabScan" }, (response) => {
    const statusBox = document.getElementById("statusBox");
    
    if (!response || response.error) {
      renderNeutralStatus(statusBox, "Sistem Sayfası", "Tarama aktif değil.");
      return;
    }

    const { result, url } = response;
    
    if (!result) {
      // Eğer taranmadıysa veya muaf tutulmuşsa
      renderNeutralStatus(statusBox, "Tarama Gerekli Değil", "Bu adres güvenlik taramasından muaf tutuluyor.");
      return;
    }

    renderScanStatus(statusBox, result);
  });
});

// Arayüzde nötr (muaf/sistem) durumunu çiz
function renderNeutralStatus(container, title, description) {
  container.innerHTML = `
    <div class="status-card status-neutral">
      <div class="status-icon">🛡️</div>
      <div class="status-title">${title}</div>
      <div class="status-score" style="font-size: 11px; text-align: center;">${description}</div>
    </div>
  `;
}

// Arayüzde API tarama sonucunu çiz
function renderScanStatus(container, data) {
  const isDangerous = data.verdict === "dangerous";
  const icon = isDangerous ? "🚨" : "✅";
  const statusClass = isDangerous ? "status-danger" : "status-safe";
  const title = isDangerous ? "Şüpheli / Zararlı URL!" : "Güvenli Bağlantı";
  const scoreText = `%${data.riskScore.toFixed(2)} Risk`;

  container.innerHTML = `
    <div class="status-card ${statusClass}">
      <div class="status-icon">${icon}</div>
      <div class="status-title">${title}</div>
      <div class="status-score">${scoreText}</div>
    </div>
  `;
}

// Manuel URL Sorgulama Düğmesi
document.getElementById("btnScan").addEventListener("click", async () => {
  const inputUrl = document.getElementById("manualUrl").value.trim();
  const manualResult = document.getElementById("manualResult");
  const btnScan = document.getElementById("btnScan");

  if (!inputUrl) {
    showManualResult(manualResult, "Lütfen bir URL adresi girin.", "danger");
    return;
  }

  // URL şeması yoksa otomatik http:// ekle
  let formattedUrl = inputUrl;
  if (!inputUrl.startsWith("http://") && !inputUrl.startsWith("https://")) {
    formattedUrl = "http://" + inputUrl;
  }

  try {
    new URL(formattedUrl);
  } catch (e) {
    showManualResult(manualResult, "Geçersiz URL formatı yazdınız.", "danger");
    return;
  }

  // Yükleniyor durumunu göster
  btnScan.disabled = true;
  btnScan.textContent = "Taranıyor...";
  manualResult.classList.add("hidden");

  try {
    const response = await fetch(BACKEND_API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url: formattedUrl })
    });

    if (!response.ok) {
      throw new Error(`Sunucu Hatası: ${response.status}`);
    }

    const data = await response.json();
    const isDangerous = data.verdict === "dangerous";
    const resultText = isDangerous 
      ? `🚨 ŞÜPHELİ SİTE (Risk: %${data.riskScore.toFixed(2)})`
      : `✅ GÜVENLİ SİTE (Risk: %${data.riskScore.toFixed(2)})`;
    
    showManualResult(manualResult, resultText, isDangerous ? "danger" : "success");
  } catch (error) {
    showManualResult(manualResult, `Bağlantı hatası: Sunucuya ulaşılamadı.`, "danger");
  } finally {
    btnScan.disabled = false;
    btnScan.textContent = "Analiz Et";
  }
});

// Arama sonucunu pop-up içinde gösteren yardımcı fonksiyon
function showManualResult(element, text, type) {
  element.textContent = text;
  element.className = `manual-result ${type}`;
  element.classList.remove("hidden");
}
